# Exploratory Data Analysis (EDA) Sample Project

This project demonstrates basic EDA techniques on a sample HR dataset using pandas, seaborn, and matplotlib.

## Project Structure
- `notebooks/`: Contains the main Jupyter notebook with EDA.
- `data/`: (Optional) Add your dataset here if using an external CSV file.
- `requirements.txt`: Python dependencies.
- `README.md`: Project description and setup instructions.

## How to Run
1. Clone the repository:
```bash
git clone https://github.com/your-username/EDA_Sample_Project.git
```

2. Navigate into the project directory and install dependencies:
```bash
cd EDA_Sample_Project
pip install -r requirements.txt
```

3. Open the notebook:
```bash
jupyter notebook notebooks/eda_sample.ipynb
```
